
import 'package:flutter/material.dart';
import 'package:linkusol_task/routes/route_screen.dart';
import 'package:linkusol_task/view/screens/account/account_screen.dart';
import 'package:linkusol_task/view/screens/chat/chat_screen.dart';
import 'package:linkusol_task/view/screens/favourate/favourate_screen.dart';
import 'package:linkusol_task/view/screens/home/home_screen.dart';
import 'package:linkusol_task/view/screens/main_screen/main_screen.dart';
import 'package:linkusol_task/view/screens/notifications/notifications_screen.dart';

class Routes {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case RouteName.initial:
        return MaterialPageRoute(builder: (context) => const MainScreen());
      case RouteName.home:
        return MaterialPageRoute(builder: (context) => const HomeScreen());

      case RouteName.account:
        return MaterialPageRoute(builder: (context) => const AccountScreen());
      case RouteName.chat:
        return MaterialPageRoute(builder: (context) => const ChatScreen());

      case RouteName.favourate:
        return MaterialPageRoute(builder: (context) => const FavourateScreen());

      case RouteName.notification:
        return MaterialPageRoute(builder: (context) => const NotificationsScreen());
      default:
        return MaterialPageRoute(
            builder: (context) => const Scaffold(
                  body: Center(
                    child: Text("No Route Defined"),
                  ),
                ));
    }
  }
}
