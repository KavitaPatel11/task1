class RouteName{
  static const String initial="/";
  static const String home="home";
  static const String account="account";
  static const String chat="chat";
  static const String favourate="favourate";
  static const String notification="notification";
}