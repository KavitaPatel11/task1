// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';
import 'package:readmore/readmore.dart';

import 'package:linkusol_task/utills/app_colors.dart';
import 'package:linkusol_task/utills/text_theme.dart';
import 'package:linkusol_task/view/widgets/default_button.dart';
import 'package:linkusol_task/view/widgets/my_heading.dart';

class MyCardWidget extends StatelessWidget {
  final int id;
  final String name;
  final String image;
  final String distance;
  final String? description;
  final VoidCallback onPress;
  const MyCardWidget({
    Key? key,
    required this.id,
    required this.name,
    required this.image,
    required this.distance,
    required this.onPress, required this.description,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.zero,
      padding: EdgeInsets.zero,
      height: size.height,
      width: size.width,
      decoration: BoxDecoration(
        color: AppColor.accentWhite,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(
            color: Color.fromRGBO(238, 238, 238, 1),
            blurRadius: 2.0, // has the effect of softening the shadow
            spreadRadius: 2.0, // has the effect of extending the shadow
            offset: Offset(
              1.0, // horizontal, move right 10
              7.0, // vertical, move down 10
            ),
          )
        ],
      ),
      child: Stack(
        fit: StackFit.expand,
        alignment: Alignment.center,
        children: [
          Container(
            margin: EdgeInsets.zero,
            padding: EdgeInsets.zero,
            height: size.height * 0.5,
            width: size.width,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              image:
                  DecorationImage(fit: BoxFit.cover, image: AssetImage(image)),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              margin: EdgeInsets.zero,
              padding: const EdgeInsets.only(
                  top: 15, left: 10, right: 10, bottom: 20),
              width: size.width,
              decoration: BoxDecoration(
                color: AppColor.accentWhite,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  myHeadingText(context, name, distance),
                  Wrap(
                    direction: Axis.horizontal,
                    children: [
                      SizedBox(
                          width: size.width * 0.29,
                          child: DefaultButton(
                              btnColor: AppColor.neturalYellow,
                              text: "Blogging")),
                      SizedBox(
                          width: size.width * 0.3,
                          child: DefaultButton(
                              btnColor: AppColor.neturalYellow,
                              text: "Photography")),
                      SizedBox(
                          width: size.width * 0.2,
                          child: DefaultButton(
                              btnColor: AppColor.neturalYellow,
                              text: "vlogging")),
                    ],
                  ),
                  Padding(
                    padding: EdgeInsets.all(16.0),
                    child: ReadMoreText(
                      description.toString(),
                      trimLines: 3,
                      style: TextStyle(color: Colors.black),
                      colorClickableText: Colors.pink,
                      trimMode: TrimMode.Line,
                      trimCollapsedText: '...Read more',
                      trimExpandedText: ' Less',
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Looking For",
                            style: Texttheme.titleRegular.copyWith(
                              color: AppColor.defaultBlackColor,
                            )),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                            width: size.width * 0.2,
                            child: const DefaultButton(text: "Team")),
                        SizedBox(
                            width: size.width * 0.2,
                            child: const DefaultButton(text: "Friend")),
                        SizedBox(
                            width: size.width * 0.2,
                            child: const DefaultButton(text: "Coffefe")),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
              right: 30,
              bottom: 30,
              child: FloatingActionButton(
                mini: true,
                onPressed: onPress,
                child: const Icon(Icons.person_add_alt_1),
              ))
        ],
      ),
    );
  }
}
