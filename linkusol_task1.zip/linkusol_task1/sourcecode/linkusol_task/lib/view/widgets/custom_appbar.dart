import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:linkusol_task/utills/app_colors.dart';
import 'package:linkusol_task/utills/constent_images.dart';


class CustomAppBar extends StatefulWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback? onPress;
  const CustomAppBar({Key? key, required this.title, this.onPress})
      : preferredSize = const Size.fromHeight(kToolbarHeight),
        super(key: key);

  @override
  final Size preferredSize; // default is 56.0

  @override
  // ignore: library_private_types_in_public_api
  _CustomAppBarState createState() => _CustomAppBarState();
}

class _CustomAppBarState extends State<CustomAppBar> {
  @override
  Widget build(BuildContext context) {
    return AppBar(
      elevation: 0,
      backgroundColor: Theme.of(context).primaryColor,
      leading: IconButton(
          onPressed: () {},
          icon: SvgPicture.asset(
            ConstentsSvgImages.arrowBackIcon,
            height: 30,
            width: 30,
            color: AppColor.accentWhite,
          )),
      title: Text(widget.title.toString()),
      actions: [
       IconButton(
                onPressed: widget.onPress,
                icon:const Icon(CupertinoIcons.arrow_turn_up_left)),
        IconButton(onPressed: () {}, icon: const Icon(Icons.menu))
      ],
    );
  }
}
