import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:linkusol_task/utills/app_colors.dart';
import 'package:linkusol_task/utills/text_theme.dart';

myHeadingText(BuildContext context, String text1, String text2) {
  return Padding(
    padding: const EdgeInsets.all(10.0),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          text1,
          style: Texttheme.heading.copyWith(fontWeight: FontWeight.bold),
        ),
        Expanded(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(Icons.location_on,size: 14,color: AppColor.accentLightGrey,),
              Text(text2,
                  style: Texttheme.subTitle.copyWith(
                    color: AppColor.accentLightGrey,
                  )),
            ],
          ),
        ),
      ],
    ),
  );
}
