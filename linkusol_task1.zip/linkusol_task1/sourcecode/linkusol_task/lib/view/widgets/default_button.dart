import 'package:flutter/widgets.dart';
import 'package:linkusol_task/utills/app_colors.dart';

class DefaultButton extends StatelessWidget {
  final String text;
  final Color? btnColor;
  const DefaultButton({super.key, required this.text, this.btnColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(2),
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
          color:
              btnColor ?? AppColor.accentWhite,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: AppColor.accentLightGrey)),
      child: Center(
        child: Text(text),
      ),
    );
  }
}
