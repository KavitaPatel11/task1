import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:linkusol_task/modal/userdata_model.dart';
import 'package:linkusol_task/view/widgets/custom_appbar.dart';
import 'package:linkusol_task/view/widgets/mycard_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  CarouselController buttonCarouselController = CarouselController();

  final int _initialPage = 1;

  List items = foodUserModels;

  List removedUserList = [];

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return SafeArea(
        child: Scaffold(
            appBar: CustomAppBar(
              onPress: () {
                buttonCarouselController.previousPage(
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.linear);
              },
              title: "Food Buddy",
            ),
            body: Stack(
              children: [
                Container(
                  height: size.height * 0.4,
                  decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor,
                      borderRadius: const BorderRadius.only(
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      )),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: CarouselSlider(
                    carouselController: buttonCarouselController,
                    options: CarouselOptions(
                      padEnds: false,
                      scrollPhysics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      height: size.height,
                      autoPlay: false,
                      enlargeCenterPage: true,
                      viewportFraction: 0.85,
                      // aspectRatio: 2.0,
                      enableInfiniteScroll: false,

                      initialPage: _initialPage,
                    ),
                    items: items.map((item) {
                      return Builder(
                        builder: (BuildContext context) {
                          return MyCardWidget(
                            id: item.id,
                            name: item.name,
                            image: item.image,
                            distance: item.distance,
                            onPress: () {
                              setState(() {
                                items.removeWhere((i) => i.id == item.id);
                              });
                            },
                            description: item.description,
                          );
                        },
                      );
                    }).toList(),
                  ),
                ),
              ],
            )));
  }
}
