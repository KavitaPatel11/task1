import 'package:flutter/material.dart';

class FavourateScreen extends StatelessWidget {
  const FavourateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const SafeArea(child:Scaffold(
      body: Center(child: Text("FavourateScreen"),)));
  }
}