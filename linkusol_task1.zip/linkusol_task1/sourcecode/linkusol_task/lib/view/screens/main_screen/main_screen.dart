import 'package:flutter/material.dart';
import 'package:linkusol_task/utills/app_colors.dart';
import 'package:linkusol_task/view/screens/account/account_screen.dart';
import 'package:linkusol_task/view/screens/chat/chat_screen.dart';
import 'package:linkusol_task/view/screens/favourate/favourate_screen.dart';
import 'package:linkusol_task/view/screens/home/home_screen.dart';
import 'package:linkusol_task/view/screens/notifications/notifications_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int currentIndex = 0;
  List children = <Widget>[
    const HomeScreen(),
    const FavourateScreen(),
    const ChatScreen(),
    const NotificationsScreen(),
    const AccountScreen()
  ];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: children[currentIndex],
            bottomNavigationBar: BottomNavigationBar(
                selectedItemColor: Theme.of(context).primaryColor,
                unselectedItemColor: AppColor.accentLightGrey,
                onTap: ((value) {
                  setState(() {
                    currentIndex = value;
                  });
                }),
                selectedFontSize: 0,
                items: const [
                  BottomNavigationBarItem(
                    icon: Icon(Icons.home),
                    label: '',
                  ),
                  BottomNavigationBarItem(
                    icon:Icon(Icons.emoji_emotions),
                    label: '',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.chat),
                    label: '',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.notifications),
                    label: '',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.person),
                    label: '',
                  ),
                ])));
  }
}
