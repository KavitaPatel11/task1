
class UserModel {
  final int id;
  final String name, description, image, distance;

  UserModel({
    required this.id,
    required this.image,
    required this.name,
    this.distance = "5.0 km",
    required this.description,
  });
}

// Our food UserModels

List<UserModel> foodUserModels = [
  UserModel(
    id: 1,
    image: 'assets/images/image1.jpg',
    name: "Ram",
    description: description,
  ),
  UserModel(
    id: 2,
    image: 'assets/images/image2.jpg',
    name: "Gita",
    description: description,
  ),
  UserModel(
    id: 3,
    image: 'assets/images/image3.jpg',
    name: "Rani",
    description: description,
  ),
  UserModel(
    id: 4,
    image: 'assets/images/image4.jpg',
    name: "Radhika",
    description: description,
  ),
  UserModel(
    id: 5,
    image: 'assets/images/image5.jpg',
    name: "Arti",
    description: description,
  ),
  UserModel(
    id: 6,
    image: 'assets/images/image6.jpg',
    name: "Rahul",
    description: description,
  ),
  UserModel(
    id: 7,
    image: 'assets/images/image2.jpg',
    name: "Sushil",
    description: description,
  ),
  UserModel(
    id: 8,
    image: 'assets/images/image3.jpg',
    name: "Sonam",
    description: description,
  ),
  UserModel(
    id: 9,
    image: 'assets/images/image4.jpg',
    name: "Khushi",
    description: description,
  ),
  UserModel(
    id: 10,
    image: 'assets/images/image5.jpg',
    name: "Aradhana",
    description: description,
  ),
];

const String description =
    "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy";
