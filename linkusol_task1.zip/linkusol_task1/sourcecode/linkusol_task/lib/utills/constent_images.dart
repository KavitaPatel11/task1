// ignore_for_file: non_constant_identifier_names

class ConstentsSvgImages {
  static String BASEURL = "assets/";
  static String homeIcon = "${BASEURL}icons/home.svg";
  static String smiliIcon = "${BASEURL}icons/smili.svg";
  static String chatIcon = "${BASEURL}icons/chat.svg";
  static String wellIcon = "${BASEURL}icons/well_icon.svg";
  static String userIcon = "${BASEURL}icons/user.svg";
  static String adduserIcon = "${BASEURL}icons/adduser.svg";
  static String arrowBackIcon = "${BASEURL}icons/arrow_back.svg";
  static String backIcon = "${BASEURL}icons/back.svg";
}
