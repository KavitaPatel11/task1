import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:linkusol_task/routes/route_name.dart';
import 'package:linkusol_task/routes/route_screen.dart';
import 'package:linkusol_task/utills/app_colors.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  SystemChrome.setSystemUIOverlayStyle(
    SystemUiOverlayStyle(
      systemNavigationBarColor: AppColor.accentDarkGrey, // navigation bar color
      statusBarColor: AppColor.primaryColor, // status bar color
    ),
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(primaryColor: AppColor.primaryColor),
      debugShowCheckedModeBanner: false,
      initialRoute: RouteName.initial,
      onGenerateRoute: Routes.generateRoute,
    );
  }
}
